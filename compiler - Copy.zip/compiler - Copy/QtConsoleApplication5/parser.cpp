#include "parser.h"

void CParser::work(CReaderWriter* writer, QVector<SDataToken> dataTokens, QVector<SCodeToken> codeTokens, 
					QVector<QString> dataTable, QString filename)
{
	m_dataTokens = dataTokens;
	m_codeTokens = codeTokens;
	m_dataTable = dataTable;
	//	writer->addSection(writeHeader(writer->getSignature(), writer -> getVersion()), filename);

	writeDataSection();
	writeCodeSection();

	//QByteArray v_out = writeDataSection();
//	QByteArray v_out = 123;
//	QByteArray v_out = writeDataSection();
//	qDebug() << "size of datasection" << v_out.size();
//	for (int i = 0; i < v_out.size(); ++i)
//	{
//		//char ch = v_out[i];
//		//qDebug() << ch;
////		qDebug() << reinterpret_cast<char>(v_out[i]);
//		qDebug() << static_cast<char>(v_out[i]);
//
//	}
//

	//writer->addSection(writeDataSection());
	//writer->addSection(writeCodeSection());
	//writer->addSection(writeDataTableSection());
	////writer->addSection(writeCodeTableSection());
	//writer->write(filename);
}

QByteArray CParser::writeCodeSection()
{

	qDebug() << "writeCodeSection\n\n";
	QByteArray out;
	int offset = 0;			//size of codeSection

	QHash<QString, int>::Iterator i;

	qDebug() << "nameGrammer";
	for (i = m_nameGrammar.begin(); i != m_nameGrammar.end(); ++i)
	{
		qDebug() << i.key() << " : " << i.value();
	}
	qDebug() << "end of nameGrammar\n\n";


	qDebug() << "\n\ndataTable";
	for (int i = 0; i < m_dataTable.size(); ++i)
	{
		qDebug() << i << " = " << m_dataTable[i];
	}
	qDebug() << "end of dataTable\n\n";


	for (int i = 0; i < m_codeTokens.size(); i++)
	{
		qDebug() << "m_codeTokens[i].opcode.opcode = " <<  m_codeTokens[i].opcode.opcode;
		out.append(m_codeTokens[i].opcode.opcode);
		offset += sizeof m_codeTokens[i].opcode.opcode;
		qDebug() << "offset = " << offset;
		
		for (int j = 0; j < m_codeTokens[i].argValue.size(); j++)
		{
			if ((j == 0 && m_codeTokens[i].opcode.arg1Type == static_cast<uint16>(EArgumentType::Data)) ||
				(j == 1 && m_codeTokens[i].opcode.arg2Type == static_cast<uint16>(EArgumentType::Data)) ||
				(j == 2 && m_codeTokens[i].opcode.arg3Type == static_cast<uint16>(EArgumentType::Data)))
			{
				int indexInDataTable = m_codeTokens[i].argValue[j];
				qDebug() << "indexInDataTable = " << indexInDataTable;
				QString identifierName = m_dataTable[indexInDataTable];
				qDebug() << "identifierName = " << identifierName;
				int indexInSymbolTable = m_nameGrammar[identifierName];
				out.append(indexInSymbolTable);
				qDebug() << " indexInSymbolTable = " << indexInSymbolTable;
				offset += sizeof indexInSymbolTable;
				qDebug() << "\t\t\t offset = " << offset;
			}			
			else
			{
				out.append(m_codeTokens[i].argValue[j]);
				qDebug() << " m_codeTokens[i].argValue[j] = " << m_codeTokens[i].argValue[j];
				offset += sizeof m_codeTokens[i].argValue[j];
				qDebug() << "\t\t\t offset = " << offset;
			}
		}
		qDebug() << "out.size() = " << out.size();
	}
	qDebug() << "end of writeCodeSection\n\n";
 	return out;
}

QByteArray CParser::writeDataSection()
{
	qDebug() << "writeDataSection\n\n";

	QByteArray out;
	int offset = 0;		//size of dataSection
	uint16 zero = 0;
	int remainder = 0;
	int typeToSize = 0;
	int currOffset = 0;
//	int prevOffset = 0;

	for (int i = 0; i < m_dataTokens.size(); ++i)
	{
//		qDebug() << "\n\n\ni = " << i << "\n\n\n";
		int dataType = static_cast<int>(m_dataTokens[i].type);
//		qDebug() << "dataType = " << dataType;
		typeToSize = static_cast<int> (pow(2, dataType));
//		qDebug() << "typeToSize = " << typeToSize;

		if (currOffset % typeToSize != 0)
		{
			int remainder = typeToSize - (currOffset % typeToSize);
//			qDebug() << " remainder = " << remainder;
			while (remainder != 0)
			{
				out.append(zero);
//				qDebug() << "zero	" << zero;		///////
				remainder--;
//				qDebug() << "remainder--" << remainder;
				++currOffset;
			}
		}
		m_nameGrammar[m_dataTokens[i].identifierName] = currOffset;
//		qDebug() << m_dataTokens[i].identifierName << " = " << m_nameGrammar[m_dataTokens[i].identifierName];
		out.append(m_dataTokens[i].value);
//		qDebug() << "m_dataTokens[i].value = " << m_dataTokens[i].value;
		currOffset += typeToSize;
//		qDebug() << "currOffset = " << currOffset;
//		qDebug() << "SIZE = " << out.size();
	}
//	qDebug() << out.size(); ///////////

	qDebug() << "\n\nend of writeDataSection\n\n";
	return out;
}
QByteArray CParser::writeDataTableSection()
{
	QByteArray out;
	int offset = 0;
	for (int i = 0; i < m_dataTokens.size(); i++)
	{
		int dataType = static_cast<int>(m_dataTokens[i].type);
		out.append(dataType);
		out.append(m_dataTokens[i].identifierName);
		out.append(m_dataTokens[i].value);
		out.append(m_dataTokens[i].line);
		offset += sizeof(int) + m_dataTokens[i].identifierName.size() +
			/*dataType +*/ sizeof(int);
	}
	return out;
}
QByteArray CParser::writeCodeTableSection()
{
	QByteArray out;
	int offset = 0;
	/*for (int i = 0; i < m_codeTokens.size(); i++)
	{
	out << m_codeTokens[i].opcode.opcode;

	}*/
	//	return offset;
	return out;
}

